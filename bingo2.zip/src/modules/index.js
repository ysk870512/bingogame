import { combineReducers } from 'redux';
import play from './play';

const rootReducer = combineReducers({
    play,
});

export default rootReducer;
